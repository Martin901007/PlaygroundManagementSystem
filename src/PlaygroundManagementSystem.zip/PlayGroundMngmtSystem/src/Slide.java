public class Slide extends PlayGround {

	Slide() {
		super(1);
	}

}
