public class Carousel extends PlayGround {

	Carousel(int size) {

		super(size);

	}

}
