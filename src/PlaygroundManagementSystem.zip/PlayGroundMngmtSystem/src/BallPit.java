public class BallPit extends PlayGround {

	BallPit(int size) {

		super(size);

	}

}
